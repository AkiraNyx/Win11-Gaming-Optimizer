import type { ComponentPropsWithRef, ReactNode, RefObject } from 'react';
import type { MotionPhase } from '../motion.js';
export type DialogControls = {
    close: () => void;
    phase: MotionPhase;
};
export type DialogTriggerProps = Pick<ComponentPropsWithRef<'button'>, 'onClick' | 'aria-haspopup' | 'aria-controls' | 'aria-expanded'> & {
    ref: RefObject<HTMLButtonElement | null>;
};
export type DialogProps = Omit<ComponentPropsWithRef<'dialog'>, 'open' | 'children'> & {
    open?: boolean;
    defaultOpen?: boolean;
    onOpenChange?: (open: boolean) => void;
    onAfterClose?: () => void;
    trigger?: (props: DialogTriggerProps) => ReactNode;
    children?: ReactNode | ((controls: DialogControls) => ReactNode);
    initialFocusRef?: RefObject<HTMLElement | null>;
    returnFocus?: () => HTMLElement | null;
    /** Use a modeless native dialog when a host supplies its own interaction boundary. */
    modal?: boolean;
};
export declare function Dialog({ open: controlled, defaultOpen, onOpenChange, onAfterClose, trigger, children, initialFocusRef, returnFocus, modal, className, ref, id: explicitId, onCancel, onClose, ...props }: DialogProps): import("react").JSX.Element;
//# sourceMappingURL=Dialog.d.ts.map