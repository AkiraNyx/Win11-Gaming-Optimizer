import type { ComponentPropsWithRef, ReactNode } from 'react';
import type { ButtonProps } from './Button.js';
export type SegmentOption = {
    value: string;
    label: ReactNode;
    disabled?: boolean;
    buttonProps?: ButtonProps & {
        [key: `data-${string}`]: string | number | boolean | undefined;
    };
};
export type SegmentedControlProps = Omit<ComponentPropsWithRef<'div'>, 'onChange'> & {
    label: string;
    options: readonly SegmentOption[];
    value?: string;
    defaultValue?: string;
    onValueChange?: (value: string) => void;
    appearance?: 'pill' | 'underline';
};
export declare function SegmentedControl({ label, options, value, defaultValue, onValueChange, appearance, ref, className, ...props }: SegmentedControlProps): import("react").JSX.Element;
//# sourceMappingURL=SegmentedControl.d.ts.map