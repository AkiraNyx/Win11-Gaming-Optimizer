import type { ComponentPropsWithRef } from 'react';
import { iconPaths } from './icon-paths.js';
export type IconName = keyof typeof iconPaths;
export type IconProps = ComponentPropsWithRef<'svg'> & {
    name: IconName;
};
export declare function Icon({ name, className, ...props }: IconProps): import("react").JSX.Element;
//# sourceMappingURL=Icon.d.ts.map