import type { ComponentPropsWithRef, ReactNode } from 'react';
export type ThemeName = 'day' | 'night';
export type ThemeProps = ComponentPropsWithRef<'div'> & {
    theme?: ThemeName;
};
export declare function OverlayHost({ root, children }: {
    root: HTMLElement | null;
    children: ReactNode;
}): import("react").JSX.Element;
export declare function Theme({ theme, className, children, ref, ...props }: ThemeProps): import("react").JSX.Element;
export declare function useOverlayRoot(): HTMLElement | null;
//# sourceMappingURL=Theme.d.ts.map