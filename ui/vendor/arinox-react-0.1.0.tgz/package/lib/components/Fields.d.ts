import type { ComponentPropsWithRef, ReactNode } from 'react';
export type InputProps = ComponentPropsWithRef<'input'> & {
    invalid?: boolean;
};
export declare function Input({ invalid, className, ...props }: InputProps): import("react").JSX.Element;
export type TextareaProps = ComponentPropsWithRef<'textarea'> & {
    invalid?: boolean;
};
export declare function Textarea({ invalid, className, ...props }: TextareaProps): import("react").JSX.Element;
export type SelectProps = ComponentPropsWithRef<'select'> & {
    invalid?: boolean;
};
export declare function Select({ invalid, className, ...props }: SelectProps): import("react").JSX.Element;
export type CheckboxProps = Omit<ComponentPropsWithRef<'input'>, 'type'> & {
    indeterminate?: boolean;
};
export declare function Checkbox({ indeterminate, className, ref, ...props }: CheckboxProps): import("react").JSX.Element;
export type SwitchProps = Omit<ComponentPropsWithRef<'input'>, 'type' | 'role'>;
export declare function Switch({ className, ...props }: SwitchProps): import("react").JSX.Element;
export type FieldProps = ComponentPropsWithRef<'div'> & {
    label: ReactNode;
    htmlFor: string;
    hint?: ReactNode;
    error?: ReactNode;
};
export declare function Field({ label, htmlFor, hint, error, children, className, ...props }: FieldProps): import("react").JSX.Element;
//# sourceMappingURL=Fields.d.ts.map