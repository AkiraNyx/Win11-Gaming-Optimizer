import type { ComponentPropsWithRef, ReactNode, RefObject } from 'react';
export type MenuTriggerProps = Pick<ComponentPropsWithRef<'button'>, 'onClick' | 'onKeyDown' | 'aria-expanded' | 'aria-controls' | 'aria-haspopup'> & {
    ref: RefObject<HTMLButtonElement | null>;
};
export type MenuProps = Omit<ComponentPropsWithRef<'div'>, 'children'> & {
    trigger: (props: MenuTriggerProps) => ReactNode;
    children: ReactNode;
    open?: boolean;
    defaultOpen?: boolean;
    onOpenChange?: (open: boolean) => void;
    onAfterClose?: () => void;
    triggerRef?: RefObject<HTMLButtonElement | null>;
};
export declare function Menu({ trigger, children, open: controlled, defaultOpen, onOpenChange, onAfterClose, triggerRef, ref, className, id: explicitId, onKeyDown, ...props }: MenuProps): import("react").JSX.Element;
export type MenuItemProps = Omit<ComponentPropsWithRef<'button'>, 'onSelect' | 'role'> & {
    onSelect?: () => void;
};
export declare function MenuItem({ onSelect, onClick, className, type, ...props }: MenuItemProps): import("react").JSX.Element;
//# sourceMappingURL=Menu.d.ts.map