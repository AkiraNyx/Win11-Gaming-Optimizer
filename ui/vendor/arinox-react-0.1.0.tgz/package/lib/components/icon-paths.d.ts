export declare const iconPaths: {
    grid: import("react").JSX.Element;
    star: import("react").JSX.Element;
    folder: import("react").JSX.Element;
    book: import("react").JSX.Element;
    sliders: import("react").JSX.Element;
    search: import("react").JSX.Element;
    plus: import("react").JSX.Element;
    more: import("react").JSX.Element;
    arrow: import("react").JSX.Element;
    list: import("react").JSX.Element;
    moon: import("react").JSX.Element;
    sun: import("react").JSX.Element;
    edit: import("react").JSX.Element;
    close: import("react").JSX.Element;
    check: import("react").JSX.Element;
};
//# sourceMappingURL=icon-paths.d.ts.map