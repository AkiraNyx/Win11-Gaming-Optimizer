import type { ComponentPropsWithRef, ReactNode } from 'react';
export type TabItem = {
    value: string;
    label: ReactNode;
    content: ReactNode;
    disabled?: boolean;
};
export type TabsProps = Omit<ComponentPropsWithRef<'div'>, 'onChange'> & {
    items: readonly TabItem[];
    label: string;
    value?: string;
    defaultValue?: string;
    onValueChange?: (value: string) => void;
};
export declare function Tabs({ items, label, value, defaultValue, onValueChange, className, ref, ...props }: TabsProps): import("react").JSX.Element;
//# sourceMappingURL=Tabs.d.ts.map