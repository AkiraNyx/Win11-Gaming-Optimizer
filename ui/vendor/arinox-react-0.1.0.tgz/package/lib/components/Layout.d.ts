import type { ComponentPropsWithRef } from 'react';
export type CardProps = ComponentPropsWithRef<'article'> & {
    surface?: 'paper' | 'glass';
};
export declare function Card({ surface, className, ...props }: CardProps): import("react").JSX.Element;
export type GlassProps = ComponentPropsWithRef<'div'>;
export declare function Glass({ className, ...props }: GlassProps): import("react").JSX.Element;
type Spacing = 0 | 1 | 2 | 3 | 4 | 5 | 6 | 8 | 10 | 12 | 16;
export type LayoutProps = ComponentPropsWithRef<'div'> & {
    gap?: Spacing;
};
export declare function Stack({ gap, style, className, ...props }: LayoutProps): import("react").JSX.Element;
export declare function Inline({ gap, style, className, ...props }: LayoutProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=Layout.d.ts.map