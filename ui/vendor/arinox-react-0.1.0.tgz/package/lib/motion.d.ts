import type { Ref, RefObject } from 'react';
export declare function useReducedMotion(): boolean;
export declare function useEvent<A extends unknown[], R>(handler: (...args: A) => R): (...args: A) => R;
export declare function useControllable<T>(value: T | undefined, initial: T, onChange?: (value: T) => void): readonly [T, (next: T | ((current: T) => T)) => void];
export declare function useNode<T extends HTMLElement>(external?: Ref<T>): readonly [T | null, (value: T | null) => void];
export declare function motionTokens(node: Element): {
    fast: number;
    base: number;
    slow: number;
    enter: import("animejs").EasingFunction;
    exit: import("animejs").EasingFunction;
};
export type MotionPhase = 'closed' | 'opening' | 'open' | 'closing';
export declare function usePresence(open: boolean, node: HTMLElement | null, kind: 'menu' | 'dialog', prepare: () => void, exited: () => void): {
    readonly present: boolean;
    readonly phase: "closed" | "closing" | "open" | "opening";
};
export declare function useIndicator(root: HTMLElement | null, selected: unknown): void;
export declare function useLayoutTransition(root: RefObject<HTMLElement | null>): (update: () => void) => void;
//# sourceMappingURL=motion.d.ts.map